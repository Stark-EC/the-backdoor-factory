If you want to use the aplib.dll with your bcb project, link with the aplib.lib file here in the LibForDll directory.
If you don't want to use the dll, then just link with the static aplib.lib in the ..\..\lib\omf directory.
The sample project uses the static lib in ..\..\lib\omf